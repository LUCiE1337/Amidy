import java.util.ArrayList;
import java.util.List;

class Pracownik {
    private String imie;
    private String nazwisko;
    private String stanowisko;
    private double pensja;

    public Pracownik(String imie, String nazwisko, String stanowisko, double pensja) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.stanowisko = stanowisko;
        this.pensja = pensja;
    }

    public String getImie() {
        return imie;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public String getStanowisko() {
        return stanowisko;
    }

    public double getPensja() {
        return pensja;
    }

    public void setPensja(double pensja) {
        this.pensja = pensja;
    }
}

class Firma {
    private List<Pracownik> pracownicy = new ArrayList<>();


    public void dodajPracownika(String imie, String nazwisko, String stanowisko, double pensja) {
        Pracownik pracownik = new Pracownik(imie, nazwisko, stanowisko, pensja);
        pracownicy.add(pracownik);
    }

    public void wyswietlPracownikow() {
        System.out.println("Lista pracowników:");
        for (Pracownik pracownik : pracownicy) {
            System.out.println(pracownik.getImie() + " " + pracownik.getNazwisko() + " - " + pracownik.getStanowisko() +
                    ", Pensja: " + pracownik.getPensja());
        }
    }

    public void pracownicyNaStanowisku(String stanowisko) {
        System.out.println("Pracownicy na stanowisku " + stanowisko + ":");
        for (Pracownik pracownik : pracownicy) {
            if (pracownik.getStanowisko().equals(stanowisko)) {
                System.out.println(pracownik.getImie() + " " + pracownik.getNazwisko() + " - " + pracownik.getStanowisko() +
                        ", Pensja: " + pracownik.getPensja());
            }
        }
    }
    public void zmienPensje(String imie, String nazwisko, double nowaPensja)
    {
        for (Pracownik pracownik : pracownicy)
        {
            if (pracownik.getImie().equals(imie) && pracownik.getNazwisko().equals(nazwisko))
            {
                pracownik.setPensja(nowaPensja);
                System.out.println("Pensja pracownika " + imie + " " + nazwisko + " została zmieniona na " + nowaPensja);
            }
        }
    }
}

public class Main
{
    public static void main(String[] args) {
        Firma firma = new Firma();
        firma.dodajPracownika("Jan", "Kowalski", "Programista", 6000);
        firma.dodajPracownika("Anna", "Nowak", "Kierownik projektu", 8000);
        firma.dodajPracownika("Marek", "Zięba", "Programista", 6500);
        firma.wyswietlPracownikow();
        firma.pracownicyNaStanowisku("Programista");
        firma.wyswietlPracownikow();
        firma.zmienPensje("Jan", "Kowalski", 7000);
    }
}
